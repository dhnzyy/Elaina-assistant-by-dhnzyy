╭─❍──────────────❍─╮
 𝗧𝗘𝗥𝗜𝗠𝗔 𝗞𝗔𝗦𝗜𝗛 𝗠𝗘𝗠𝗕𝗨𝗔𝗧 𝗦𝗖𝗥𝗜𝗣𝗧 𝗜𝗡𝗜
╰─❍──────────────❍─╯
[SCRIPT INI FREE NO ENC YA!!!]
## JANGAN DI JUAL KONTOLLLL LU NGEMIS PEPEEEEEKKKKKKKKKKKKKKKK KALO INIII SC FREE ASU LU GW BANTAI LU TAIK
╭── ⋆⋅☆⋅⋆ ──╮
│  ✦ 𝗩𝗶𝘁𝗮
│  ✦ 𝗗𝗲𝘄𝗶
│  ✦ 𝗟𝗮𝘆𝗹𝗮𝗮 
│  ✦ 𝗔𝗰𝗵𝗮 
│  ✦ 𝗡𝗼𝘃𝗶 
╰── ⋆⋅☆⋅⋆ ──╯

╭──── ⭑ 𝗦𝗢𝗖𝗜𝗔𝗟 𝗠𝗘𝗗𝗜𝗔 ⭑ ────╮
│ 🌐 *Instagram:* @laylaa_imup
│ ▶️ *YouTube:* @laylaa-yes
│ 💬 *Telegram:* @laylaa_imup ( ON ) 
│ 📘 *Facebook:* fb.com/ ( ga punya ) 
│ 💬 *WhatsApp:* ( KENON ) 
╰────────────────────────────╯